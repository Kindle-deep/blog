﻿---
title: 相册
layout: "gallery"
aside: false
top_img: false
comments: false
---

<div class="gallery-group-main">
{% galleryGroup '壁紙' '世俗的欲望' '/List/gallery/wallpaper' https://i.loli.net/2019/11/10/T7Mu8Aod3egmC4Q.png %}
{% galleryGroup '随机图API原图' '质量超高' '/List/gallery/随机图API' https://img.ssykawa.com/image/pc/00072.jpg %}
</div>

